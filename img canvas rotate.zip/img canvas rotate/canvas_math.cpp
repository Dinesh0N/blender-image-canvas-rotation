#include <Python.h>
#include <cmath>

static PyObject* rotate_delta(PyObject* self, PyObject* args) {
    float dx, dy, rotation, aspect;
    
    // Parse arguments: dx, dy, rotation angle (radians), aspect ratio
    if (!PyArg_ParseTuple(args, "ffff", &dx, &dy, &rotation, &aspect)) {
        return NULL;
    }
    
    // Inverse rotation to apply screen delta to the canvas coordinates
    float cos_r = cosf(rotation);
    float sin_r = sinf(rotation);
    
    float rdx = dx * cos_r + dy * sin_r;
    float rdy = -dx * sin_r + dy * cos_r;
    
    // Maintain aspect ratio scaling if needed, usually just dx, dy in View2D space
    // If aspect is passed and needs applying:
    rdx *= 1.0f;
    rdy *= aspect; // Depends on how Python side manages it
    
    // Return the rotated deltas as a tuple
    return Py_BuildValue("ff", rdx, rdy);
}

static PyMethodDef CanvasMathMethods[] = {
    {"rotate_delta", rotate_delta, METH_VARARGS, "Rotate mouse delta by canvas rotation"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef canvasmathmodule = {
    PyModuleDef_HEAD_INIT,
    "canvas_math",
    "C++ Math bindings for canvas rotation",
    -1,
    CanvasMathMethods
};

PyMODINIT_FUNC PyInit_canvas_math(void) {
    return PyModule_Create(&canvasmathmodule);
}

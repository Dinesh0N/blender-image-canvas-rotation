import ctypes
import math

class rctf(ctypes.Structure):
    _fields_ = [("xmin", ctypes.c_float),
                ("xmax", ctypes.c_float),
                ("ymin", ctypes.c_float),
                ("ymax", ctypes.c_float)]

class rcti(ctypes.Structure):
    _fields_ = [("xmin", ctypes.c_int),
                ("xmax", ctypes.c_int),
                ("ymin", ctypes.c_int),
                ("ymax", ctypes.c_int)]

class View2D(ctypes.Structure):
    _fields_ = [("tot", rctf),
                ("cur", rctf),
                ("vert", rcti),
                ("hor", rcti),
                ("mask", rcti),
                ("min", ctypes.c_float * 2),
                ("max", ctypes.c_float * 2),
                ("minzoom", ctypes.c_float),
                ("maxzoom", ctypes.c_float),
                ("scroll", ctypes.c_short),
                ("scroll_ui", ctypes.c_short),
                ("keeptot", ctypes.c_short),
                ("keepzoom", ctypes.c_short),
                ("keepofs", ctypes.c_short),
                ("flag", ctypes.c_short),
                ("align", ctypes.c_short),
                ("winx", ctypes.c_short),
                ("winy", ctypes.c_short),
                ("oldwinx", ctypes.c_short),
                ("oldwiny", ctypes.c_short),
                ("around", ctypes.c_short),
                ("alpha_vert", ctypes.c_char),
                ("alpha_hor", ctypes.c_char),
                ("_pad", ctypes.c_char * 2),
                ("page_size_y", ctypes.c_float)
                ]

def apply_pan_delta(region, dx_pixel, dy_pixel, angle):
    """
    Translates a screen space pixel delta into View2D `cur` coordinate change,
    factoring in the visual canvas rotation.
    """
    v2d_ptr = region.view2d.as_pointer()
    v2d = View2D.from_address(v2d_ptr)
    
    # Convert screen delta to view delta using unrotated View2D scale
    x0, y0 = region.view2d.region_to_view(0, 0)
    x1, y1 = region.view2d.region_to_view(dx_pixel, dy_pixel)
    vdx = x1 - x0
    vdy = y1 - y0
    
    # Rotate delta by inverted angle
    cos_r = math.cos(angle)
    sin_r = math.sin(angle)
    
    rdx = vdx * cos_r + vdy * sin_r
    rdy = -vdx * sin_r + vdy * cos_r
    
    # Subtract from `cur` (panning moves the window in the opposite direction of the mouse)
    v2d.cur.xmin -= rdx
    v2d.cur.xmax -= rdx
    v2d.cur.ymin -= rdy
    v2d.cur.ymax -= rdy


def apply_zoom_delta(region, zoom_factor, focus_pixel_x, focus_pixel_y, angle):
    """
    Applies zoom scaling dynamically by editing `cur`. Does not require rotation math directly
    since zoom is a scalar, but we must expand/contract around a focal point.
    """
    v2d_ptr = region.view2d.as_pointer()
    v2d = View2D.from_address(v2d_ptr)
    
    # View space coordinates of the mouse focus
    fx, fy = region.view2d.region_to_view(focus_pixel_x, focus_pixel_y)
    
    cur_w = v2d.cur.xmax - v2d.cur.xmin
    cur_h = v2d.cur.ymax - v2d.cur.ymin
    
    # Proportional focus position on the unrotated 'cur' mapping
    prop_x = (fx - v2d.cur.xmin) / cur_w if cur_w > 0 else 0.5
    prop_y = (fy - v2d.cur.ymin) / cur_h if cur_h > 0 else 0.5
    
    # Apply zoom scale
    new_w = cur_w / zoom_factor
    new_h = cur_h / zoom_factor
    
    # Expand from focus point
    v2d.cur.xmin = fx - (new_w * prop_x)
    v2d.cur.xmax = v2d.cur.xmin + new_w
    v2d.cur.ymin = fy - (new_h * prop_y)
    v2d.cur.ymax = v2d.cur.ymin + new_h

bl_info = {
    "name": "Image Canvas Rotation",
    "description": "Visual canvas rotation for the Image Editor (stock Blender)",
    "author": "Antigravity",
    "version": (8, 0, 0),
    "blender": (5, 1, 0),
    "location": "Image Editor > Alt+MMB",
    "category": "Image",
}

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from gpu_extras.presets import draw_texture_2d
from mathutils import Matrix
import math

# ── Rotation Math (ported from canvas_rotation_feature.patch) ────────

def _rotation_aspect(region):
    """Compute aspect ratio for rotation (from patch UI_view2d_rotation_aspect).
    Accounts for non-square pixel mapping between view coords and region pixels."""
    v2d = region.view2d
    bl_x, bl_y = v2d.region_to_view(0, 0)
    tr_x, tr_y = v2d.region_to_view(region.width, region.height)
    cur_w = abs(tr_x - bl_x)
    cur_h = abs(tr_y - bl_y)
    mask_w = float(region.width)
    mask_h = float(region.height)
    if cur_w > 1e-8 and cur_h > 1e-8 and mask_w > 0:
        return (mask_h / cur_h) / (mask_w / cur_w)
    return 1.0


def _canvas_center():
    """Image occupies (0,0)–(1,1) in Image Editor's normalized view space."""
    return 0.5, 0.5


def _get_bg_color():
    try:
        c = bpy.context.preferences.themes[0].image_editor.space.back
        return (c[0], c[1], c[2], 1.0)
    except Exception:
        return (0.15, 0.15, 0.15, 1.0)


# ── POST_VIEW Draw Handler ──────────────────────────────────────────
# Runs AFTER DRW draws the un-rotated image but BEFORE gizmos are drawn,
# so we can cover the original and redraw rotated without hiding gizmos.

def _draw_rotated_canvas():
    try:
        region = getattr(bpy.context, 'region', None)
        space = getattr(bpy.context, 'space_data', None)
        if not region or not space:
            return

        wm = bpy.context.window_manager
        if not hasattr(wm, 'canvas_rotation'):
            return
        angle = wm.canvas_rotation
        if abs(angle) < 1e-7:
            return

        image = space.image
        if not image:
            return

        v2d = region.view2d

        # Visible area bounds in view space (for background coverage)
        bl_x, bl_y = v2d.region_to_view(0, 0)
        tr_x, tr_y = v2d.region_to_view(region.width, region.height)

        # Aspect ratio from patch
        aspect = _rotation_aspect(region)

        # Canvas center in view space
        cx, cy = _canvas_center()

        # 1. Cover the un-rotated DRW-drawn image with background
        #    Use large padding to cover rotated-out areas too
        pad = max(abs(tr_x - bl_x), abs(tr_y - bl_y)) * 2
        bg = _get_bg_color()
        shader_flat = gpu.shader.from_builtin('UNIFORM_COLOR')
        verts_bg = [
            (bl_x - pad, bl_y - pad), (tr_x + pad, bl_y - pad),
            (tr_x + pad, tr_y + pad), (bl_x - pad, tr_y + pad)
        ]
        batch_bg = batch_for_shader(shader_flat, 'TRI_FAN', {"pos": verts_bg})
        shader_flat.bind()
        shader_flat.uniform_float("color", bg)
        batch_bg.draw(shader_flat)

        # 2. Draw image rotated around canvas center with aspect correction
        #    Matrix matches patch's view2d_apply_rotation_matrix():
        #    translate(cx,cy) → scale(1, 1/aspect) → rotate(-angle) → scale(1, aspect) → translate(-cx,-cy)
        texture = gpu.texture.from_image(image)

        gpu.state.blend_set('ALPHA')
        gpu.matrix.push()

        gpu.matrix.translate((cx, cy))
        gpu.matrix.scale((1.0, 1.0 / aspect))
        gpu.matrix.multiply_matrix(Matrix.Rotation(-angle, 4, 'Z'))
        gpu.matrix.scale((1.0, aspect))
        gpu.matrix.translate((-cx, -cy))

        # Image occupies (0,0)–(1,1) in view space
        draw_texture_2d(texture, (0, 0), 1.0, 1.0)

        gpu.matrix.pop()
        gpu.state.blend_set('NONE')

    except Exception:
        import traceback
        traceback.print_exc()


# ── Gizmo ────────────────────────────────────────────────────────────

class IMAGE_GGT_canvas_rotate(bpy.types.GizmoGroup):
    bl_idname = "IMAGE_GGT_canvas_rotate"
    bl_label = "Canvas Rotate Gizmo"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'}

    @classmethod
    def poll(cls, context):
        return context.space_data.show_gizmo_navigate

    def setup(self, context):
        gz = self.gizmos.new("GIZMO_GT_dial_2d")
        gz.target_set_prop("offset", context.window_manager, "canvas_rotation")
        gz.use_draw_value = True
        gz.color = 0.5, 0.5, 0.5
        gz.alpha = 0.5
        gz.color_highlight = 0.8, 0.8, 0.8
        gz.alpha_highlight = 0.8
        self.gz = gz

    def draw_prepare(self, context):
        gz = getattr(self, "gz", None)
        if gz is None:
            return
        region = context.region
        gz.matrix_basis[0][3] = region.width - 50
        gz.matrix_basis[1][3] = region.height - 150


# ── Operators ────────────────────────────────────────────────────────

class IMAGE_OT_canvas_rotate(bpy.types.Operator):
    """Rotate the Image Editor canvas visually"""
    bl_idname = "image.canvas_rotate"
    bl_label = "Rotate Canvas"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'IMAGE_EDITOR'

    def _mouse_angle(self, region, event):
        cx = region.width / 2.0
        cy = region.height / 2.0
        return math.atan2(event.mouse_region_y - cy, event.mouse_region_x - cx)

    def invoke(self, context, event):
        self.original_rotation = context.window_manager.canvas_rotation
        self.start_angle = self._mouse_angle(context.region, event)
        self._region = context.region
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('SCROLL_XY')
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            angle = self._mouse_angle(self._region, event)
            delta = angle - self.start_angle
            while delta > math.pi:
                delta -= 2.0 * math.pi
            while delta < -math.pi:
                delta += 2.0 * math.pi

            new_rot = self.original_rotation + delta
            while new_rot > math.pi:
                new_rot -= 2.0 * math.pi
            while new_rot < -math.pi:
                new_rot += 2.0 * math.pi

            context.window_manager.canvas_rotation = new_rot
            context.region.tag_redraw()
            return {'RUNNING_MODAL'}

        elif event.type in {'LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE'}:
            if event.value == 'RELEASE':
                context.window.cursor_modal_restore()
                return {'FINISHED'}
        elif event.type == 'ESC':
            context.window_manager.canvas_rotation = self.original_rotation
            context.region.tag_redraw()
            context.window.cursor_modal_restore()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}


class IMAGE_OT_canvas_pan_rotated(bpy.types.Operator):
    """Pan the view with rotation-aware delta (from patch view_pan_apply_ex)"""
    bl_idname = "image.canvas_pan_rotated"
    bl_label = "Pan Canvas (Rotation-Aware)"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'IMAGE_EDITOR'

    def invoke(self, context, event):
        self.last_x = event.mouse_region_x
        self.last_y = event.mouse_region_y
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('SCROLL_XY')
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            dx = float(event.mouse_region_x - self.last_x)
            dy = float(event.mouse_region_y - self.last_y)
            self.last_x = event.mouse_region_x
            self.last_y = event.mouse_region_y

            angle = context.window_manager.canvas_rotation

            # Convert pixel delta to view-space delta
            v2d = context.region.view2d
            x0, y0 = v2d.region_to_view(0, 0)
            x1, y1 = v2d.region_to_view(dx, dy)
            vdx = x1 - x0
            vdy = y1 - y0

            # Apply rotation to delta (from patch view_pan_apply_ex)
            cos_r = math.cos(angle)
            sin_r = math.sin(angle)
            rdx = vdx * cos_r + vdy * sin_r
            rdy = -vdx * sin_r + vdy * cos_r

            # Apply to view2d cur rect
            import ctypes

            class rctf(ctypes.Structure):
                _fields_ = [("xmin", ctypes.c_float), ("xmax", ctypes.c_float),
                            ("ymin", ctypes.c_float), ("ymax", ctypes.c_float)]

            ptr = v2d.as_pointer()
            cur = rctf.from_address(ptr + 16)  # cur is at offset 16 (after tot)
            cur.xmin -= rdx
            cur.xmax -= rdx
            cur.ymin -= rdy
            cur.ymax -= rdy

            context.region.tag_redraw()
            return {'RUNNING_MODAL'}

        elif event.type in {'LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE'}:
            if event.value == 'RELEASE':
                context.window.cursor_modal_restore()
                return {'FINISHED'}
        elif event.type == 'ESC':
            context.window.cursor_modal_restore()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}


class IMAGE_OT_canvas_zoom_rotated(bpy.types.Operator):
    """Zoom the view with rotation-aware focal point"""
    bl_idname = "image.canvas_zoom_rotated"
    bl_label = "Zoom Canvas (Rotation-Aware)"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'IMAGE_EDITOR'

    def invoke(self, context, event):
        self.last_y = event.mouse_region_y
        self.focus_x = event.mouse_region_x
        self.focus_y = event.mouse_region_y
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('SCROLL_Y')
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            dy = event.mouse_region_y - self.last_y
            self.last_y = event.mouse_region_y

            if dy != 0:
                import ctypes

                class rctf(ctypes.Structure):
                    _fields_ = [("xmin", ctypes.c_float), ("xmax", ctypes.c_float),
                                ("ymin", ctypes.c_float), ("ymax", ctypes.c_float)]

                v2d = context.region.view2d
                ptr = v2d.as_pointer()
                cur = rctf.from_address(ptr + 16)

                zoom_factor = 1.0 + (dy * 0.005)
                fx, fy = v2d.region_to_view(self.focus_x, self.focus_y)

                cur_w = cur.xmax - cur.xmin
                cur_h = cur.ymax - cur.ymin
                prop_x = (fx - cur.xmin) / cur_w if cur_w > 0 else 0.5
                prop_y = (fy - cur.ymin) / cur_h if cur_h > 0 else 0.5

                new_w = cur_w / zoom_factor
                new_h = cur_h / zoom_factor
                cur.xmin = fx - (new_w * prop_x)
                cur.xmax = cur.xmin + new_w
                cur.ymin = fy - (new_h * prop_y)
                cur.ymax = cur.ymin + new_h

                context.region.tag_redraw()
            return {'RUNNING_MODAL'}

        elif event.type in {'LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE'}:
            if event.value == 'RELEASE':
                context.window.cursor_modal_restore()
                return {'FINISHED'}
        elif event.type == 'ESC':
            context.window.cursor_modal_restore()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}


class IMAGE_OT_reset_canvas_rotation(bpy.types.Operator):
    bl_idname = "image.reset_canvas_rotation"
    bl_label = "Reset Canvas Rotation"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'IMAGE_EDITOR'

    def execute(self, context):
        context.window_manager.canvas_rotation = 0.0
        context.region.tag_redraw()
        return {'FINISHED'}


# ── UI ───────────────────────────────────────────────────────────────

def draw_canvas_rotation_ui(self, context):
    layout = self.layout
    col = layout.column()
    row = col.row(align=True)
    row.prop(context.window_manager, "canvas_rotation", text="Canvas Rotation")
    row.operator("image.reset_canvas_rotation", text="", icon='X')


def update_canvas_rotation(self, context):
    for area in context.screen.areas:
        if area.type == 'IMAGE_EDITOR':
            area.tag_redraw()


# ── Registration ─────────────────────────────────────────────────────

_handle_draw = None
addon_keymaps = []

classes = (
    IMAGE_GGT_canvas_rotate,
    IMAGE_OT_canvas_rotate,
    IMAGE_OT_canvas_pan_rotated,
    IMAGE_OT_canvas_zoom_rotated,
    IMAGE_OT_reset_canvas_rotation,
)


def register():
    global _handle_draw

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.canvas_rotation = bpy.props.FloatProperty(
        name="Canvas Rotation", subtype='ANGLE', default=0.0,
        update=update_canvas_rotation)

    # POST_VIEW: runs after DRW image draw, before gizmos
    _handle_draw = bpy.types.SpaceImageEditor.draw_handler_add(
        _draw_rotated_canvas, (), 'WINDOW', 'POST_VIEW')

    bpy.types.IMAGE_PT_view_display.append(draw_canvas_rotation_ui)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Image Generic', space_type='IMAGE_EDITOR')
        kmi = km.keymap_items.new('image.canvas_rotate', 'MIDDLEMOUSE', 'PRESS', alt=True)
        addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new('image.canvas_pan_rotated', 'MIDDLEMOUSE', 'PRESS', shift=True)
        addon_keymaps.append((km, kmi))
        kmi = km.keymap_items.new('image.canvas_zoom_rotated', 'MIDDLEMOUSE', 'PRESS', ctrl=True)
        addon_keymaps.append((km, kmi))


def unregister():
    global _handle_draw

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    bpy.types.IMAGE_PT_view_display.remove(draw_canvas_rotation_ui)

    if _handle_draw:
        bpy.types.SpaceImageEditor.draw_handler_remove(_handle_draw, 'WINDOW')
        _handle_draw = None

    if hasattr(bpy.types.WindowManager, 'canvas_rotation'):
        del bpy.types.WindowManager.canvas_rotation

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()

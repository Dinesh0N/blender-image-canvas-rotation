import re

with open("__init__.py", "r") as f:
    content = f.read()

gizmo_code = """
class IMAGE_GGT_canvas_rotate(bpy.types.GizmoGroup):
    bl_idname = "IMAGE_GGT_canvas_rotate"
    bl_label = "Canvas Rotate Gizmo"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'}

    @classmethod
    def poll(cls, context):
        # Only show when navigation gizmos are enabled?
        return context.space_data.show_gizmo_navigate

    def setup(self, context):
        gz = self.gizmos.new("GIZMO_GT_dial_2d")
        gz.target_set_prop("offset", context.window_manager, "canvas_rotation")
        gz.use_draw_value = True
        gz.color = 0.5, 0.5, 0.5
        gz.alpha = 0.5
        gz.color_highlight = 0.8, 0.8, 0.8
        gz.alpha_highlight = 0.8
        self.gz = gz

    def draw_prepare(self, context):
        # Position gizmo in top right corner below standard navigate gizmos
        region = context.region
        self.gz.matrix_basis[0][3] = region.width - 50
        self.gz.matrix_basis[1][3] = region.height - 150
"""

if "class IMAGE_GGT_canvas_rotate" not in content:
    content = content.replace("class IMAGE_OT_canvas_rotate", gizmo_code + "\nclass IMAGE_OT_canvas_rotate")
    # Add to classes
    content = content.replace("IMAGE_OT_canvas_rotate,", "IMAGE_GGT_canvas_rotate,\n    IMAGE_OT_canvas_rotate,")
    
    with open("__init__.py", "w") as f:
        f.write(content)
    print("Patched __init__.py with Gizmo")
else:
    print("Already patched")

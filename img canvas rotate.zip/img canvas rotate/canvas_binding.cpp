#include <Python.h>
#include <cmath>
#include <cstdint>

// Minimal DNA memory layouts representing unpatched Blender standard ABI
struct rctf { float xmin, xmax, ymin, ymax; };
struct rcti { int xmin, xmax, ymin, ymax; };

struct View2D_ABI {
    rctf tot;
    rctf cur;
    rcti vert;
    rcti hor;
    rcti mask;
    float min[2];
    float max[2];
    float minzoom;
    float maxzoom;
    short scroll;
    short scroll_ui;
    short keeptot;
    short keepzoom;
    short keepofs;
    short flag;
    short align;
    short winx;
    short winy;
    short oldwinx;
    short oldwiny;
    short around;
    char alpha_vert;
    char alpha_hor;
    char _pad[2];
    float page_size_y;
};

// Math routines directly extracted from src/view2d.cc patch!
static float UI_view2d_rotation_aspect(const View2D_ABI *v2d) {
    const float cur_width = v2d->cur.xmax - v2d->cur.xmin;
    const float cur_height = v2d->cur.ymax - v2d->cur.ymin;
    const float mask_width = float(v2d->mask.xmax - v2d->mask.xmin + 1);
    const float mask_height = float(v2d->mask.ymax - v2d->mask.ymin + 1);

    if (cur_width != 0.0f && cur_height != 0.0f && mask_width != 0.0f) {
        return (mask_height / cur_height) / (mask_width / cur_width);
    }
    return 1.0f;
}

static void view2d_rotate_point_inverse(const View2D_ABI *v2d, float* r_x, float* r_y, float rotation) {
    // Assuming center pivot
    float cx = (v2d->cur.xmin + v2d->cur.xmax) * 0.5f;
    float cy = (v2d->cur.ymin + v2d->cur.ymax) * 0.5f;
    float aspect = UI_view2d_rotation_aspect(v2d);

    const float dx = *r_x - cx;
    const float dy = (*r_y - cy) * aspect;
    const float cos_r = std::cos(-rotation);
    const float sin_r = std::sin(-rotation);
    
    *r_x = cx + dx * cos_r - dy * sin_r;
    *r_y = cy + (dx * sin_r + dy * cos_r) / aspect;
}

// Python C-Extension Endpoints

static PyObject* apply_pan_delta(PyObject* self, PyObject* args) {
    uintptr_t ptr;
    float vdx, vdy, rotation;
    if (!PyArg_ParseTuple(args, "Kfff", &ptr, &vdx, &vdy, &rotation)) {
        return NULL;
    }

    View2D_ABI* v2d = reinterpret_cast<View2D_ABI*>(ptr);
    
    // Inverted affine math extracted from view_pan_apply_ex
    const float cos_r = std::cos(rotation);
    const float sin_r = std::sin(rotation);
    const float rdx = vdx * cos_r + vdy * sin_r;
    const float rdy = -vdx * sin_r + vdy * cos_r;

    v2d->cur.xmin -= rdx;
    v2d->cur.xmax -= rdx;
    v2d->cur.ymin -= rdy;
    v2d->cur.ymax -= rdy;

    Py_RETURN_NONE;
}

static PyObject* apply_zoom_delta(PyObject* self, PyObject* args) {
    uintptr_t ptr;
    float zoom_factor, fx, fy;
    if (!PyArg_ParseTuple(args, "Kfff", &ptr, &zoom_factor, &fx, &fy)) {
        return NULL;
    }

    View2D_ABI* v2d = reinterpret_cast<View2D_ABI*>(ptr);
    
    float cur_w = v2d->cur.xmax - v2d->cur.xmin;
    float cur_h = v2d->cur.ymax - v2d->cur.ymin;
    
    float prop_x = (cur_w > 0.0f) ? (fx - v2d->cur.xmin) / cur_w : 0.5f;
    float prop_y = (cur_h > 0.0f) ? (fy - v2d->cur.ymin) / cur_h : 0.5f;
    
    float new_w = cur_w / zoom_factor;
    float new_h = cur_h / zoom_factor;
    
    v2d->cur.xmin = fx - (new_w * prop_x);
    v2d->cur.xmax = v2d->cur.xmin + new_w;
    v2d->cur.ymin = fy - (new_h * prop_y);
    v2d->cur.ymax = v2d->cur.ymin + new_h;

    Py_RETURN_NONE;
}

static PyObject* rotate_point_inv(PyObject* self, PyObject* args) {
    uintptr_t ptr;
    float x, y, rotation;
    if (!PyArg_ParseTuple(args, "Kfff", &ptr, &x, &y, &rotation)) {
        return NULL;
    }

    View2D_ABI* v2d = reinterpret_cast<View2D_ABI*>(ptr);
    view2d_rotate_point_inverse(v2d, &x, &y, rotation);
    
    return Py_BuildValue("ff", x, y);
}

static PyMethodDef CanvasBindingMethods[] = {
    {"apply_pan_delta", apply_pan_delta, METH_VARARGS, "Apply mathematically rotated panning on View2D cur rect"},
    {"apply_zoom_delta", apply_zoom_delta, METH_VARARGS, "Apply proper viewport zoom on View2D cur rect"},
    {"rotate_point_inv", rotate_point_inv, METH_VARARGS, "Rotate point inverse mapped to View2D"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef canvasbindingmodule = {
    PyModuleDef_HEAD_INIT,
    "canvas_binding",
    "Proper Native C++ Binding for Canvas Rotation extracted from src/view2d.cc",
    -1,
    CanvasBindingMethods
};

PyMODINIT_FUNC PyInit_canvas_binding(void) {
    return PyModule_Create(&canvasbindingmodule);
}

/* SPDX-FileCopyrightText: 2024 Blender Authors
 *
 * SPDX-License-Identifier: GPL-2.0-or-later */

/** \file
 * \ingroup edinterface
 *
 * \name Custom 2D Navigation Rotation Gizmo
 *
 * \brief Circle-shaped compass gizmo for 2D canvas rotation.
 * Draws a circle background with X/Y axis indicators and rotation angle.
 *
 * Modeled after VIEW3D_GT_navigate_rotate but simplified for 2D views.
 */

#include <cmath>

#include "BLI_math_base.h"
#include "BLI_math_vector.h"
#include "BLI_rect.h"

#include "BKE_context.hh"

#include "GPU_immediate.hh"
#include "GPU_immediate_util.hh"
#include "GPU_matrix.hh"
#include "GPU_state.hh"

#include "BLF_api.hh"

#include "UI_interface.hh"
#include "UI_resources.hh"
#include "UI_view2d.hh"

#include "WM_api.hh"
#include "WM_types.hh"

#include "ED_gizmo_library.hh"
#include "ED_screen.hh"

#include "DNA_view2d_types.h"

namespace blender::ui {

/** Radius of the entire gizmo background in pixels. */
static constexpr float V2D_NAV_RADIUS_FAC = 40.0f;
/** Size of axis handle balls relative to radius. */
static constexpr float V2D_AXIS_HANDLE_SIZE = 0.22f;
/** Font size for labels relative to radius. */
static constexpr float V2D_AXIS_TEXT_FAC = V2D_AXIS_HANDLE_SIZE * 1.3f;
/** Scale factor for the center ball relative to standard axis balls. */
static constexpr float V2D_CENTER_BALL_SCALE = 1.08f;

static float v2d_nav_radius()
{
  return V2D_NAV_RADIUS_FAC * UI_SCALE_FAC;
}

static float v2d_axis_line_width()
{
  return 2.0f * U.pixelsize;
}

static float v2d_axis_ring_width()
{
  return 1.5f * U.pixelsize;
}

/* -------------------------------------------------------------------- */
/** \name Axis Drawing Helpers
 * \{ */

struct AxisInfo {
  float angle_offset;
  int axis;  /* 0=X, 1=Y */
  bool is_pos;
};

static constexpr AxisInfo g_axes[4] = {
    {0.0f, 0, true},            /* +X: right */
    {float(M_PI), 0, false},    /* -X: left */
    {float(M_PI_2), 1, true},   /* +Y: up */
    {float(-M_PI_2), 1, false}, /* -Y: down */
};

/**
 * Compute the highlight part index for an axis.
 * Part indices: 1=+X, 2=-X, 3=+Y, 4=-Y, 5=center.
 */
static int v2d_axis_part_index(const int axis, const bool is_pos)
{
  return (axis * 2) + (is_pos ? 1 : 2);
}

/** \} */

/* -------------------------------------------------------------------- */
/** \name Draw
 * \{ */

static void v2d_navigate_draw(const bContext *C, wmGizmo *gz)
{
  const ARegion *region = CTX_wm_region(C);
  const View2D *v2d = &region->v2d;
  const float rotation = v2d->rotation;
  const bool is_hover = ((gz->state & WM_GIZMO_STATE_HIGHLIGHT) != 0);

  const float cx = gz->matrix_basis[3][0];
  const float cy = gz->matrix_basis[3][1];
  const float rad = v2d_nav_radius();
  const float line_width = v2d_axis_line_width();
  const float ring_width = v2d_axis_ring_width();
  const float ball_rad = rad * V2D_AXIS_HANDLE_SIZE;
  const float length_frac = 1.0f - V2D_AXIS_HANDLE_SIZE;

  /* Background color of the space, used to mix axis colors. */
  float view_color[4];
  ui::theme::get_color_3fv(TH_BACK, view_color);
  view_color[3] = 1.0f;

  float viewport_size[4];
  GPU_viewport_size_get_f(viewport_size);

  /* Font setup. */
  const int font_id = BLF_default();
  BLF_disable(font_id, BLF_ROTATION | BLF_SHADOW | BLF_ASPECT | BLF_WORD_WRAP);
  BLF_enable(font_id, BLF_BOLD);
  BLF_size(font_id, rad * V2D_AXIS_TEXT_FAC);

  draw_roundbox_corner_set(ui::CNR_ALL);
  GPU_polygon_smooth(false);
  GPU_blend(GPU_BLEND_ALPHA);

  /* Background circle — visible only on hover. */
  if (is_hover) {
    const float bg_color[4] = {0.45f, 0.45f, 0.45f, 0.4f};
    GPU_matrix_push();
    GPU_matrix_translate_2f(cx, cy);
    const rctf rect = {-rad, rad, -rad, rad};
    ui::draw_roundbox_4fv(&rect, true, rad, bg_color);
    GPU_matrix_pop();
  }

  /* Draw axes (+X, -X, +Y, -Y). */
  for (int i = 0; i < 4; i++) {
    const int axis = g_axes[i].axis;
    const bool is_pos = g_axes[i].is_pos;
    const int part_index = v2d_axis_part_index(axis, is_pos);
    const bool is_highlight = (part_index == gz->highlight_part);

    /* Axis theme color. */
    float axis_color[4];
    ui::theme::get_color_3fv(TH_AXIS_X + axis, axis_color);
    axis_color[3] = 1.0f;

    /* Compute axis endpoint. Negate rotation to match canvas direction. */
    const float a = -rotation + g_axes[i].angle_offset;
    const float ex = cx + cosf(a) * rad * length_frac;
    const float ey = cy + sinf(a) * rad * length_frac;

    /* Color: positive axes use full color, negative axes use dimmed. */
    float color[4];
    interp_v4_v4v4(color, view_color, axis_color, is_pos ? 0.75f : 0.25f);
    if (!is_pos) {
      color[3] = 1.0f;
    }

    /* Axis line. */
    {
      float sx = cx, sy = cy;
      const float len = len_v2v2(float2{sx, sy}, float2{ex, ey});
      if (len > 0.0f) {
        const float dx = (ex - sx) / len;
        const float dy = (ey - sy) / len;
        sx -= dx * (line_width * 0.66f);
        sy -= dy * (line_width * 0.66f);
      }

      GPUVertFormat *format = immVertexFormat();
      const uint pos_id = GPU_vertformat_attr_add(
          format, "pos", gpu::VertAttrType::SFLOAT_32_32_32);
      const uint color_id = GPU_vertformat_attr_add(
          format, "color", gpu::VertAttrType::SFLOAT_32_32_32_32);

      immBindBuiltinProgram(GPU_SHADER_3D_POLYLINE_SMOOTH_COLOR);
      immUniform2fv("viewportSize", &viewport_size[2]);
      immUniform1f("lineWidth", line_width);
      immBegin(GPU_PRIM_LINES, 2);
      immAttr4fv(color_id, color);
      immVertex3f(pos_id, sx, sy, 0.0f);
      immAttr4fv(color_id, color);
      immVertex3f(pos_id, ex, ey, 0.0f);
      immEnd();
      immUnbindProgram();
    }

    /* Axis ball. */
    {
      GPU_matrix_push();
      GPU_matrix_translate_2f(ex, ey);
      const rctf rect = {-ball_rad, ball_rad, -ball_rad, ball_rad};
      ui::draw_roundbox_4fv_ex(&rect, color, nullptr, 0.0f, color, ring_width, ball_rad);
      GPU_matrix_pop();
    }

    /* Axis label. */
    if (is_pos || is_highlight) {
      char label[3];
      if (is_pos) {
        label[0] = char('X' + axis);
        label[1] = '\0';
      }
      else {
        label[0] = '-';
        label[1] = char('X' + axis);
        label[2] = '\0';
      }

      float tw, th;
      BLF_width_and_height(font_id, label, strlen(label), &tw, &th);

      float text_color[4] = {1.0f, 1.0f, 1.0f, 1.0f};
      if (!is_highlight) {
        zero_v4(text_color);
        text_color[3] = is_hover ? 1.0f : 0.9f;
      }

      BLF_position(font_id,
                    roundf(ex - tw * (is_pos ? 0.5f : 0.55f)),
                    roundf(ey - th * 0.5f),
                    0.0f);
      BLF_color4fv(font_id, text_color);
      BLF_draw(font_id, label, strlen(label));
    }
  }

  /* Center ball — rotation angle readout. */
  {
    const bool is_highlight = (gz->highlight_part == 5);

    float z_color[4];
    ui::theme::get_color_3fv(TH_AXIS_Z, z_color);
    z_color[3] = 1.0f;

    float color[4];
    interp_v4_v4v4(color, view_color, z_color, 0.75f);

    const float center_rad = ball_rad * V2D_CENTER_BALL_SCALE;
    GPU_matrix_push();
    GPU_matrix_translate_2f(cx, cy);
    const rctf rect = {-center_rad, center_rad, -center_rad, center_rad};
    ui::draw_roundbox_4fv_ex(&rect, color, nullptr, 0.0f, color, ring_width, center_rad);
    GPU_matrix_pop();

    /* Format angle string. */
    char angle_str[16];
    float degrees = fmodf(RAD2DEGF(rotation), 360.0f);
    if (degrees < 0.0f) {
      degrees += 360.0f;
    }
    snprintf(angle_str, sizeof(angle_str), "%.0f\xC2\xB0", degrees);

    BLF_size(font_id, rad * V2D_AXIS_TEXT_FAC * 0.85f);

    float tw, th;
    BLF_width_and_height(font_id, angle_str, strlen(angle_str), &tw, &th);

    float text_color[4] = {1.0f, 1.0f, 1.0f, 1.0f};
    if (!is_highlight) {
      zero_v4(text_color);
      text_color[3] = is_hover ? 1.0f : 0.9f;
    }

    BLF_position(font_id, roundf(cx - tw * 0.5f), roundf(cy - th * 0.5f), 0.0f);
    BLF_color4fv(font_id, text_color);
    BLF_draw(font_id, angle_str, strlen(angle_str));
  }

  GPU_blend(GPU_BLEND_NONE);
  BLF_disable(font_id, BLF_BOLD);
}

/** \} */

/* -------------------------------------------------------------------- */
/** \name Hit Detection
 * \{ */

static int v2d_navigate_test_select(bContext *C, wmGizmo *gz, const int mval[2])
{
  const float rad = v2d_nav_radius();
  const float point_local[2] = {float(mval[0]) - gz->matrix_basis[3][0],
                                float(mval[1]) - gz->matrix_basis[3][1]};
  const float len_sq = len_squared_v2(point_local);

  if (len_sq > rad * rad) {
    return -1;
  }

  const ARegion *region = CTX_wm_region(C);
  if (!region) {
    return 0;
  }
  const float rotation = region->v2d.rotation;

  const float ball_rad = rad * V2D_AXIS_HANDLE_SIZE;
  const float ball_rad_sq = ball_rad * ball_rad;
  const float length_frac = 1.0f - V2D_AXIS_HANDLE_SIZE;

  int best_part = -1;
  float best_len_sq = FLT_MAX;

  for (int i = 0; i < 4; i++) {
    const float a = -rotation + g_axes[i].angle_offset;
    const float ball_pos[2] = {cosf(a) * rad * length_frac, sinf(a) * rad * length_frac};
    const float dist_sq = len_squared_v2v2(point_local, ball_pos);
    if (dist_sq <= ball_rad_sq && dist_sq < best_len_sq) {
      best_len_sq = dist_sq;
      best_part = v2d_axis_part_index(g_axes[i].axis, g_axes[i].is_pos);
    }
  }

  /* Center ball. */
  const float center_rad = ball_rad * V2D_CENTER_BALL_SCALE;
  if (len_sq <= center_rad * center_rad && len_sq < best_len_sq) {
    best_part = 5;
  }

  return (best_part != -1) ? best_part : 0;
}

/** \} */

static int v2d_navigate_cursor_get(wmGizmo * /*gz*/)
{
  return WM_CURSOR_DEFAULT;
}

static bool v2d_navigate_screen_bounds_get(const bContext *C, wmGizmo *gz, rcti *r_bounding_box)
{
  const ScrArea *area = CTX_wm_area(C);
  const float rad = v2d_nav_radius();
  r_bounding_box->xmin = int(gz->matrix_basis[3][0] + area->totrct.xmin - rad);
  r_bounding_box->ymin = int(gz->matrix_basis[3][1] + area->totrct.ymin - rad);
  r_bounding_box->xmax = int(gz->matrix_basis[3][0] + area->totrct.xmin + rad);
  r_bounding_box->ymax = int(gz->matrix_basis[3][1] + area->totrct.ymin + rad);
  return true;
}

void VIEW2D_GT_navigate_rotate(wmGizmoType *gzt)
{
  gzt->idname = "VIEW2D_GT_navigate_rotate";

  gzt->draw = v2d_navigate_draw;
  gzt->test_select = v2d_navigate_test_select;
  gzt->cursor_get = v2d_navigate_cursor_get;
  gzt->screen_bounds_get = v2d_navigate_screen_bounds_get;

  gzt->struct_size = sizeof(wmGizmo);
}

}  // namespace blender::ui

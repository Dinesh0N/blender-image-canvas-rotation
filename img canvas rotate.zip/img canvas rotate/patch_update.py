import re

with open("__init__.py", "r") as f:
    content = f.read()

update_func = """
def update_canvas_rotation(self, context):
    for area in context.screen.areas:
        if area.type == 'IMAGE_EDITOR':
            area.tag_redraw()

"""

if "def update_canvas_rotation" not in content:
    # Insert before register
    content = content.replace("def register():", update_func + "def register():")
    
    # Add update=update_canvas_rotation
    content = content.replace(
        "name=\"Canvas Rotation\", subtype='ANGLE', default=0.0)",
        "name=\"Canvas Rotation\", subtype='ANGLE', default=0.0, update=update_canvas_rotation)"
    )
    
    with open("__init__.py", "w") as f:
        f.write(content)
    print("Patched __init__.py with update callback")
else:
    print("Already patched")

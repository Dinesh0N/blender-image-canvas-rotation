from setuptools import setup, Extension

canvas_math_module = Extension('canvas_math',
                               sources=['canvas_math.cpp'])

setup(name='canvas_math',
      version='1.0',
      description='C++ Math Extension for Canvas Rotation',
      ext_modules=[canvas_math_module])
